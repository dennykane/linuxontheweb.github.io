//Imports«
import { util, api as capi } from "/sys/util.js";
import {globals} from "/sys/config.js";

const{ log, cwarn, cerr, isnum, make, mkdv} = util;
//»

export const app = function(Win, Desk) {

//Var«

let Main = Win.main;

//»


//Funcs«


//»


this.onresize=resize;
this.onappinit=()=>{//«
}//»
this.onkill=()=>{//«
cancelAnimationFrame(rafId);
};//»
this.onkeydown=(e,k)=>{//«
};//»

}
