
export const app = function(Win, Desk) {

Win.main._bgcol='#fff';
Win.main.innerHTML='<center><h1>Hello</h1></center>';

this.onkeydown=(e)=>{
console.log(e);
};

}

